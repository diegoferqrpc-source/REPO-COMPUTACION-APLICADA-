"""
almacenamiento.py
------------------
Funciones genéricas para leer y escribir archivos JSON.
Todos los módulos del proyecto (clientes, productos, pedidos, etc.)
usan estas funciones para no repetir lógica de lectura/escritura.
"""

import json
import os

CARPETA_DATOS = os.path.join(os.path.dirname(os.path.dirname(__file__)), "datos")


def leer_json(nombre_archivo):
    """
    Lee un archivo JSON dentro de la carpeta datos/ y devuelve una lista.
    Si el archivo no existe, lo crea vacío y devuelve [].
    """
    ruta = os.path.join(CARPETA_DATOS, nombre_archivo)
    if not os.path.exists(ruta):
        os.makedirs(CARPETA_DATOS, exist_ok=True)
        with open(ruta, "w", encoding="utf-8") as f:
            json.dump([], f)
        return []

    with open(ruta, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []


def escribir_json(nombre_archivo, datos):
    """
    Sobreescribe un archivo JSON dentro de la carpeta datos/ con la lista dada.
    """
    ruta = os.path.join(CARPETA_DATOS, nombre_archivo)
    os.makedirs(CARPETA_DATOS, exist_ok=True)
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(datos, f, indent=4, ensure_ascii=False)


def generar_id(lista, campo_id):
    """
    Genera el siguiente id numérico consecutivo para una lista de diccionarios,
    según el campo indicado (por ejemplo 'id' o 'codigo').
    """
    if not lista:
        return 1
    return max(item[campo_id] for item in lista) + 1
